/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.com.controle;

import javax.swing.JTextField;

/**
 *
 * @author DrKobun
 */
public class Calculo
{
    private double numero;
    private double numeroDois;
    
    public double soma()
    {
        return this.numero + this.numeroDois;
    }
    
    public double subtracao()
    {
        return numero - numeroDois;
    }
    
    public double multiplicacao()
    {
        return numero * numeroDois;
    }
    
    public double divisao()
    {
        return numero / numeroDois;
    }

    public double getNumero() 
    {
        return numero;
    }

    public void setNumero(double numero) 
    {
        this.numero = numero;
    }

    public double getNumeroDois()
    {
        return numeroDois;
    }

    public void setNumeroDois(double numeroDois) 
    {
        this.numeroDois = numeroDois;
    }

    public String soma(JTextField numeroUm, JTextField numeroDois) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
}
